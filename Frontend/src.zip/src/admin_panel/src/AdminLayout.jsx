import React from 'react';
import NavBar from './Components/NavBar/NavBar';
import Sidebar from './Components/SidebarMenu/Sidebar';
import './Admin.css'

function AdminLayout({ children }) {
    return (
        <div className="admin-panel light">
            <NavBar />
            <div className="container">
                <Sidebar />
                <main className="content">{children}</main>
            </div>
        </div>
    );
}

export default AdminLayout;
